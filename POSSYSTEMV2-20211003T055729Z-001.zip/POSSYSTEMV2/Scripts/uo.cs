﻿
using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using VRC.Udon;

public class uo : UdonSharpBehaviour
{
    void Start()
    {
        
    }
}
